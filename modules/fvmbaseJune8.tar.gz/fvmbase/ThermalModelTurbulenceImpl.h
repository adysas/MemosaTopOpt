#ifndef _THERMALMODELTURBULENCEIMPL_H_
#define _THERMALMODELTURBULENCEIMPL_H_

template<class T>
void
ThermalModel<T>::ComputeTurbulentThermalConductivity()
{
  _impl->ComputeTurbulentThermalConductivity();
}

template<class T>
void
ThermalModel<T>::ComputeTotalViscosity()
{
  _impl->ComputeTotalViscosity();
}



#endif
