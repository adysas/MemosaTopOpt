#ifndef _THERMALMODELTURBULENCE_H_
#define _THERMALMODELTURBULENCE_H_

void ComputeTurbulentThermalConductivity()
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      const int nCells = cells.getCountLevel1();
	
      TArray& eddyConductivity = dynamic_cast<TArray&>(_thermalFields.eddyConductivity[cells]);
      const TArray& eddyViscosity = dynamic_cast<const TArray&>(_thermalFields.eddyViscosity[cells]);
      const TArray& specificHeat = dynamic_cast<const TArray&>(_thermalFields.specificHeat[cells]);
      const T Pr = _options["PrandtlNumberThermalTurbulent"];

      //kT = Cp*mu/Pr

      for (int i=0; i<nCells; i++)
	{
	  eddyConductivity[i] = specificHeat[i]*eddyViscosity[i]/Pr;
	}
    }
}

void ComputeTotalViscosity()
{
const int numMeshes = _meshes.size();
 for (int n=0; n<numMeshes; n++)
   {
     const Mesh& mesh = *_meshes[n];
     const StorageSite& cells = mesh.getCells();
     const int nCells = cells.getCountLevel1();
	
     TArray& totalConductivity = dynamic_cast<TArray&>(_thermalFields.totalConductivity[cells]);
     const TArray& eddyConductivity = dynamic_cast<const TArray&>(_thermalFields.eddyConductivity[cells]);
     const TArray& conductivity = dynamic_cast<const TArray&>(_thermalFields.conductivity[cells]);
      
     for (int i=0; i<nCells; i++)
       {
	 totalConductivity[i] = eddyConductivity[i] + conductivity[i];
       }
   }
}

#endif
