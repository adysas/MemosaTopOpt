// This file os part of FVM
// Copyright (c) 2012 FVM Authors
// See LICENSE file for terms.

#include "ContactFields.h"

ContactFields::ContactFields(const string baseName):
  force(baseName + "force")

{}
