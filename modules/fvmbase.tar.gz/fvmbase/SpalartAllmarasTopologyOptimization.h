
#if !(defined(USING_ATYPE_TANGENT) || defined(USING_ATYPE_PC) || defined(USING_ATYPE_RAPID))
void buildNeighborsList(const T rMin)
{    
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      _filter.buildNeighborListWeight(mesh, rMin);
    }    
}

void applyFilter()
{
    
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      _filter.applyFilter(mesh, _spalartAllmarasFields.sensitivity, _spalartAllmarasFields.beta);
    }
}
#endif


void initResidualFieldSpalartAllmaras()
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();    	
      TArray& resSACell = dynamic_cast<TArray&>(_spalartAllmarasFields.spalartAllmarasResidual[cells]);	
      resSACell.zero();
    }  
}

/////////Copying fields and values ///////////////////

void copyNuTildeField(const Field& nuTildeDoubleField, const MeshList& meshesDouble)
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
	
      const Mesh& meshDouble = *meshesDouble[n];
      const StorageSite& cellsDouble = meshDouble.getCells();
	
      const int nCells = cells.getCountLevel1();


      TArray& nuTildeCell = dynamic_cast<TArray&>(_spalartAllmarasFields.nuTilde[cells]);
      const Array<double>& nuTildeCellDouble = dynamic_cast<const Array<double>&>(nuTildeDoubleField[cellsDouble]);

      for(int i=0; i<nCells; i++)
	{
	  nuTildeCell[i] = nuTildeCellDouble[i];
	}

    }    
}

void copyBetaField(const Field& betaDoubleField, const MeshList& meshesDouble)
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
	
      const Mesh& meshDouble = *meshesDouble[n];
      const StorageSite& cellsDouble = meshDouble.getCells();
	
      const int nCells = cells.getCountLevel1();

      TArray& betaCell = dynamic_cast<TArray&>(_spalartAllmarasFields.beta[cells]);
      const Array<double>& betaCellDouble = dynamic_cast<const Array<double>&>(betaDoubleField[cellsDouble]);
	
      for(int i=0; i<nCells; i++)
	{
	  betaCell[i] = betaCellDouble[i];
	}

    }    
}

void interpolateSourceFieldSIMP()
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();

      TArray& source = dynamic_cast<TArray&>(_spalartAllmarasFields.source[cells]);
      const TArray& beta = dynamic_cast<const TArray&>(_spalartAllmarasFields.beta[cells]);	
	
      const int nCells = cells.getCountLevel1();
		
      const T alphaSolid = _options["alphaSolid"];
      const T alphaFluid = _options["alphaFluid"];
      const T p = _options["p"];
      for ( int c=0; c<nCells; c++)
	{	    
	  source[c] = -1.0*((alphaSolid - alphaFluid)*pow(beta[c],p) + alphaFluid);
	}

    }    
}


void updateBetaFieldGhostCells()
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      MultiField::ArrayIndex tIndex(&_spalartAllmarasFields.nuTilde, &cells);
      TArray& beta = dynamic_cast<TArray&>(_spalartAllmarasFields.beta[cells]);	
      foreach(const FaceGroupPtr fgPtr, mesh.getBoundaryFaceGroups())
	{
	  const FaceGroup& fg = *fgPtr;
	  const StorageSite& faces = fg.site;
	  const int nFaces = faces.getCount();
	  const CRConnectivity& faceCells = mesh.getFaceCells(faces);
	  for(int f=0; f<nFaces; f++)
	    {
	      const int c0 = faceCells(f,0);
	      const int c1 = faceCells(f,1);
	      beta[c1] = beta[c0];
	    }
	}

    }    
}


void ComputeSpalartAllmarasResidual()
{
  //Temperature residual
  LinearSystem ls;
  initLinearization(ls);        
  ls.initAssembly();
  linearize(ls);
  MultiFieldMatrix& matrix = ls.getMatrix();
  MultiField& resSAmf = ls.getB();

  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      const int nCells = cells.getCountLevel1();
      MultiField::ArrayIndex tIndex(&_spalartAllmarasFields.nuTilde, &cells);
      TArray& resSAField = dynamic_cast<TArray&>(resSAmf[tIndex]);
      TArray& residualSACell = dynamic_cast<TArray&>(_spalartAllmarasFields.spalartAllmarasResidual[cells]);
      for(int i=0; i<nCells; i++)
	{
	  residualSACell[i] = resSAField[i];
	}
    }
}

void setObjectiveFunctionThermal(const T objFunction)
{
  _objFunctionSAModel = objFunction;
}

void printResidualField()
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      MultiField::ArrayIndex tIndex(&_spalartAllmarasFields.nuTilde, &cells);
      TArray& rCell = dynamic_cast<TArray&>(_spalartAllmarasFields.spalartAllmarasResidual[cells]);
      const int nCells = cells.getCount();    
      cout << "\n";
      for(int n=0; n<nCells; n++)
	{
	  cout << n << "th cell Residual" << rCell[n] << endl;
	}
    }    
}
 

#if !(defined(USING_ATYPE_TANGENT) || defined(USING_ATYPE_PC) || defined(USING_ATYPE_RAPID))
void dumpBetaSensistivityFields()
{

  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      MultiField::ArrayIndex tIndex(&_spalartAllmarasFields.nuTilde, &cells);
	
      TArray& betaCell = dynamic_cast<TArray&>(_spalartAllmarasFields.beta[cells]);
      TArray& sensCell = dynamic_cast<TArray&>(_spalartAllmarasFields.sensitivity[cells]);
      const int nCellsWithoutGhosts = cells.getSelfCount();
	
      //Write in binary format so that Petsc can read directly
      //Temporary variable for big endian version of the variable
      int bigEndianInteger;
      double bigEndianDouble;
      //Writing Sensitivity
      string sensitivityFileNameBinary = "Sensitivity.bin";
      FILE *sensitivityFileBinary = fopen(sensitivityFileNameBinary.c_str(),"wb"); 

      string betaFileNameBinary = "Beta.bin";
      FILE *betaFileBinary = fopen(betaFileNameBinary.c_str(),"wb"); 

      bigEndianInteger = 1211214;
      LowEndian2BigEndian(bigEndianInteger);
      fwrite(&bigEndianInteger, sizeof(int), 1, sensitivityFileBinary);
      fwrite(&bigEndianInteger, sizeof(int), 1, betaFileBinary);

      bigEndianInteger = nCellsWithoutGhosts;
      LowEndian2BigEndian(bigEndianInteger);
      fwrite(&bigEndianInteger, sizeof(int), 1, sensitivityFileBinary);
      fwrite(&bigEndianInteger, sizeof(int), 1, betaFileBinary);

      for(int i=0; i<nCellsWithoutGhosts; i++)
	{
	  bigEndianDouble = sensCell[i];
	  LowEndian2BigEndian(bigEndianDouble);
	  fwrite(&bigEndianDouble, sizeof(double), 1, sensitivityFileBinary);

	  bigEndianDouble = betaCell[i];
	  LowEndian2BigEndian(bigEndianDouble);
	  fwrite(&bigEndianDouble, sizeof(double), 1, betaFileBinary);
	}
      fclose(sensitivityFileBinary);
      fclose(betaFileBinary);
	
    }
}
#endif



//Functions used to developing code

void printNuTildeField()
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      MultiField::ArrayIndex tIndex(&_spalartAllmarasFields.nuTilde, &cells);
      TArray& nuTildeCell = dynamic_cast<TArray&>(_spalartAllmarasFields.nuTilde[cells]);
      const int nCells = cells.getCount();      
      cout << "\n";
      for(int n=0; n<nCells; n++)
	{
	  cout << "Nth Cell temperature" << nuTildeCell[n] << endl;
	}
    }    
}


void printBetaField()
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      MultiField::ArrayIndex tIndex(&_spalartAllmarasFields.nuTilde, &cells);
      TArray& betaCell = dynamic_cast<TArray&>(_spalartAllmarasFields.beta[cells]);
      const int nCells = cells.getCount();      
      cout << "\n";
      for(int n=0; n<nCells; n++)
	{
	  cout << n << "th cell beta" << betaCell[n] << endl;
	}
    }    
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////
void copyMomentumResidual(const Field& momentumRes)
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
	
      const int nCells = cells.getCountLevel1();

      VectorT3Array& momentumResidualSpalartAllmarasModel = dynamic_cast<VectorT3Array&>(_spalartAllmarasFields.momentumResidual[cells]);
      const VectorT3Array& momentumResidualFlowModel = dynamic_cast<const VectorT3Array&>(momentumRes[cells]);
	
    
      for(int i=0; i<nCells; i++)
	{
	  momentumResidualSpalartAllmarasModel[i][0] = momentumResidualFlowModel[i][0];
	  momentumResidualSpalartAllmarasModel[i][1] = momentumResidualFlowModel[i][1];
	  momentumResidualSpalartAllmarasModel[i][2] = momentumResidualFlowModel[i][2];
	}
    }
}

void copyContinuityResidual(const Field& continuityRes)
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
			
      const int nCells = cells.getCountLevel1();

      TArray& continuityResidualSpalartAllmarasModel = dynamic_cast<TArray&>(_spalartAllmarasFields.continuityResidual[cells]);
      const TArray& continuityResidualFlowModel = dynamic_cast<const TArray&>(continuityRes[cells]);
	    
      for(int i=0; i<nCells; i++)
	{
	  continuityResidualSpalartAllmarasModel[i] = continuityResidualFlowModel[i];
	}
    }
}

void copyMassFlux(const Field& massFlux)
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& faces = mesh.getFaces();
	
      const int nFaces = faces.getCount();

      TArray& convectionFlux = dynamic_cast<TArray&>(_spalartAllmarasFields.convectionFlux[faces]);
      const TArray& massFluxFlowModel = dynamic_cast<const TArray&>(massFlux[faces]);
	    
      for(int f=0; f<nFaces; f++)
	{
	  convectionFlux[f] = massFluxFlowModel[f];
	}
    }
}

void copyWallDistanceField(const Field& wallDistanceField)
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      const int nCells = cells.getCountLevel1();

      TArray& wdCellTo = dynamic_cast<TArray&>(_spalartAllmarasFields.wallDistance[cells]);
      const TArray& wdCellFrom = dynamic_cast<const TArray&> (wallDistanceField[cells]);

      for(int i=0; i<nCells; i++)
	{
	  wdCellTo[i] = wdCellFrom[i];
	}

    }    
}

void copyVorticityMagnitudeField(const Field& vorticityMagnitudeFlowField)
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      const int nCells = cells.getCountLevel1();

      TArray& vorMagTo = dynamic_cast<TArray&>(_spalartAllmarasFields.vorticityMagnitude[cells]);
      const TArray& vorMagFrom = dynamic_cast<const TArray&> (vorticityMagnitudeFlowField[cells]);

      for(int i=0; i<nCells; i++)
	{
	  vorMagTo[i] = vorMagFrom[i];
	}

    }    
}


void setObjectiveFunctionFlow(const VectorT3 objFunction, const int component)
{
  _objFunctionFlowModel = objFunction[component];
}

#if ( defined(USING_ATYPE_RAPID) )

void setIndependentStateVariablesFlowTurbulent()
{
  const int numMeshes = _meshes.size();
    
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      TArray& nuTildeCell = dynamic_cast<TArray&>(_spalartAllmarasFields.nuTilde[cells]);
      const int nCells = cells.getCountLevel1(); 
      int index = 0;
      for(int c=0; c<nCells; c++)
	{
	  index = 5*c;
	  nuTildeCell[c].setIndex(index+4);
	}
    }        
}

void setIndependentDesignVariablesThermoFluidLaminar()
{
  const int numMeshes = _meshes.size();
  for (int n=0; n<numMeshes; n++)
    {
      const Mesh& mesh = *_meshes[n];
      const StorageSite& cells = mesh.getCells();
      const int nCells = cells.getCount(); 
      const int nCellsWithoutGhosts = cells.getSelfCount();
      TArray& betaCell = dynamic_cast<TArray&>(_spalartAllmarasFields.beta[cells]);
	
      for(int c=0; c<nCellsWithoutGhosts; c++)
	{
	  betaCell[c].setIndex(5*nCells+c);
	}
      _nDesignVariables = nCellsWithoutGhosts;
    }
}


void WriteResidualGradientsToMatlabFlowTurbulent()
{
  for ( int id = 0; id < _meshes.size(); id++ )
    {
      const Mesh& mesh = *_meshes[id];
      const StorageSite& cells = mesh.getCells();    
	
      VectorT3Array& rMomentumCell = dynamic_cast<VectorT3Array&>(_spalartAllmarasFields.momentumResidual[cells]);
      TArray& rContinuityCell = dynamic_cast<TArray&>(_spalartAllmarasFields.continuityResidual[cells]);
      TArray& rSACell = dynamic_cast<TArray&>(_spalartAllmarasFields.spalartAllmarasResidual[cells]);

      const int nCells = cells.getCountLevel1();
      //const int nCellsWithoutGhosts = cells.getSelfCount();

      string SV = "DRDSV.mat";
      string DV = "DRDDV.mat";
      FILE *DRDSVFile = fopen(SV.c_str(),"wb");
      FILE *DRDDVFile = fopen(DV.c_str(),"wb");
	
      cout << endl;
      for(int i=0; i<nCells; i++)
	{
	  for (int j=0; j<3; j++)
	    {
	      //cout << rMomentumCell[i][j]._v << endl;
	      foreach(const typename Rapid::PartialDerivatives::value_type& ii, rMomentumCell[i][j]._dv)
		{
		  if (ii.first < 5*nCells)	       
		    fprintf(DRDSVFile, "%d %d %22.15le \n", 5*i+j+1, ii.first+1, ii.second); 
		  else
		    fprintf(DRDDVFile, "%d %d %22.15le \n", 5*i+j+1, ii.first-5*nCells+1, ii.second); 
		}
	    }
	  //cout << rContinuityCell[i]._v << endl;
	  foreach(const typename Rapid::PartialDerivatives::value_type& ii, rContinuityCell[i]._dv)
	    {
	      if (ii.first < 5*nCells)
		{
		  fprintf(DRDSVFile, "%d %d %22.15le \n", 5*i+3+1, ii.first+1, ii.second); 
		}
	      else
		{
		  fprintf(DRDDVFile, "%d %d %22.15le \n", 5*i+3+1, ii.first-5*nCells+1, ii.second);
		}
	    }	    
	  foreach(const typename Rapid::PartialDerivatives::value_type& ii, rSACell[i]._dv)
	    {
	      if (ii.first < 5*nCells)
		{
		  fprintf(DRDSVFile, "%d %d %22.15le \n", 5*i+4+1, ii.first+1, ii.second); 
		}
	      else
		{
		  fprintf(DRDDVFile, "%d %d %22.15le \n", 5*i+4+1, ii.first-5*nCells+1, ii.second);
		}
	    }	 
	}
      fclose(DRDSVFile);
      fclose(DRDDVFile);
    }
}

void WriteResidualGradientsToPetscFlowTurbulent()
{
  for ( int id = 0; id < _meshes.size(); id++ )
    {
      const Mesh& mesh = *_meshes[id];
      const StorageSite& cells = mesh.getCells();    
	
      VectorT3Array& rMomentumCell = dynamic_cast<VectorT3Array&>(_spalartAllmarasFields.momentumResidual[cells]);
      TArray& rContinuityCell = dynamic_cast<TArray&>(_spalartAllmarasFields.continuityResidual[cells]);
      TArray& rSACell = dynamic_cast<TArray&>(_spalartAllmarasFields.spalartAllmarasResidual[cells]);
	
      const int nCells = cells.getCountLevel1();
      //const int nCellsWithoutGhosts = cells.getSelfCount();

      int nCoeffUVWP = 0;
      int nCoeffBeta = 0;

      //Let the total number of cells be N
      //Let the total number of interior cells be M
      //N = M + Number of boundary faces

      //There are 5 state variables U, V, W, P, T; Therefore 5N state variables
      //There are M design variables

      //There are 5N residuals
      //dRdUVWP is a matrix of size 5N X 5N

      //nnzElementsRowdRdUVWP is a double array that stores the number of non-zero values in each row. Or the number of independent variables on which the residual of the cell depends upon. 
      double nnzElementsRowdRdUVWPNuT[5*nCells];
      memset(nnzElementsRowdRdUVWPNuT, 0, (5*nCells)*sizeof(double));
	
      //dRdBeta is a matrix of size 5N X M
      double nnzElementsRowdRdBeta[5*nCells];
      memset(nnzElementsRowdRdBeta, 0, (5*nCells)*sizeof(double));

      cout << endl;
      for(int i=0; i<nCells; i++)
	{
	  for (int j = 0; j < 3; j++)
	    {
		  
	      foreach(const typename Rapid::PartialDerivatives::value_type& ii, rMomentumCell[i][j]._dv)
		{
		  //First check whether the derivatives are with respect to X momentum (or U)
		  if (ii.first < 5*nCells)
		    {
		      nnzElementsRowdRdUVWPNuT[5*i+j]++;
		      nCoeffUVWP++;
		    }
		  else
		    {			  
		      nnzElementsRowdRdBeta[5*i+j]++;
		      nCoeffBeta++;
		    }
		}
	    }
	  //cout << "P-Res = " << rContinuityCell[i] << endl;
	  foreach(const typename Rapid::PartialDerivatives::value_type& ii, rContinuityCell[i]._dv)
	    {
	      if (ii.first < 5*nCells)
		{
		  nnzElementsRowdRdUVWPNuT[5*i+3]++;
		  nCoeffUVWP++;
		}
	      else
		{
		  nnzElementsRowdRdBeta[5*i+3]++;
		  nCoeffBeta++;
		}
	    }
	  //Adding temperature residual
	  foreach(const typename Rapid::PartialDerivatives::value_type& ii, rSACell[i]._dv)
	    {
	      if (ii.first < 5*nCells)
		{
		  nnzElementsRowdRdUVWPNuT[5*i+4]++;
		  nCoeffUVWP++;
		}
	      else
		{
		  nnzElementsRowdRdBeta[5*i+4]++;
		  nCoeffBeta++;
		}
	    }
	}
      
      //Write in binary format so that Petsc can read directly
      string dRdUVWPNuTFileNameBinary = "dRdUVWPNuT.binary";
      FILE *dRdUVWPNuTFileBinary = fopen(dRdUVWPNuTFileNameBinary.c_str(),"wb"); 
      string dRdBetaFileNameBinary = "dRdBeta.binary";
      FILE *dRdBetaFileBinary = fopen(dRdBetaFileNameBinary.c_str(),"wb"); 

      //Temporary variable for big endian version of the variable
      int bigEndianInteger;
      double bigEndianDouble;

      //some id number for petsc
      bigEndianInteger = 1211216;
      LowEndian2BigEndian(bigEndianInteger);
      fwrite(&bigEndianInteger, sizeof(int), 1, dRdUVWPNuTFileBinary);
      fwrite(&bigEndianInteger, sizeof(int), 1, dRdBetaFileBinary);

      //Number of rows for dRdUVWP = 5N
      bigEndianInteger = 5*nCells;
      LowEndian2BigEndian(bigEndianInteger);	
      fwrite(&bigEndianInteger, sizeof(int), 1, dRdUVWPNuTFileBinary);	  

      //Number of columns for dRdUVWP = 5N
      fwrite(&bigEndianInteger, sizeof(int), 1, dRdUVWPNuTFileBinary);
	  
      //Number of rows for dRdBeta = 5N
      fwrite(&bigEndianInteger, sizeof(int), 1, dRdBetaFileBinary);

      //Number of columns for dRdBeta = M
      //bigEndianInteger = nCellsWithoutGhosts;
      bigEndianInteger = _nDesignVariables;
      LowEndian2BigEndian(bigEndianInteger);	
      fwrite(&bigEndianInteger, sizeof(int), 1, dRdBetaFileBinary);

      // Number of non-zero elements in dRdUVWP
      bigEndianInteger = nCoeffUVWP;
      LowEndian2BigEndian(bigEndianInteger);	
      fwrite(&bigEndianInteger, sizeof(int), 1, dRdUVWPNuTFileBinary);

      // Number of non-zero elements in dRdBeta
      bigEndianInteger = nCoeffBeta;
      LowEndian2BigEndian(bigEndianInteger);	
      fwrite(&bigEndianInteger, sizeof(int), 1, dRdBetaFileBinary);

      // Number of non-zeros in each row in both dRdUVWP and dRdBeta
      for(int i=0; i<5*nCells; i++)
	{
	  bigEndianInteger = nnzElementsRowdRdUVWPNuT[i];
	  LowEndian2BigEndian(bigEndianInteger);	
	  fwrite(&bigEndianInteger, sizeof(int), 1, dRdUVWPNuTFileBinary);
	}
      for(int i=0; i<5*nCells; i++)
	{
	  bigEndianInteger = nnzElementsRowdRdBeta[i];
	  LowEndian2BigEndian(bigEndianInteger);	
	  fwrite(&bigEndianInteger, sizeof(int), 1, dRdBetaFileBinary);
	}
      // Column indices of all non-zeros elements in both dRdUVWP and dRdBeta (starting index is zero)	
      for(int i=0; i<nCells; i++)
	{
	  for (int j=0; j<3; j++)
	    {
	      foreach(const typename Rapid::PartialDerivatives::value_type& ii, rMomentumCell[i][j]._dv)
		{
		  if (ii.first < 5*nCells)
		    {
		      bigEndianInteger = ii.first;
		      LowEndian2BigEndian(bigEndianInteger);
		      fwrite(&bigEndianInteger, sizeof(int), 1, dRdUVWPNuTFileBinary);
		    }
		  else
		    {
		      bigEndianInteger = ii.first-5*nCells;
		      LowEndian2BigEndian(bigEndianInteger);
		      fwrite(&bigEndianInteger, sizeof(int), 1, dRdBetaFileBinary);
		    }
		}

	    }
	  foreach(const typename Rapid::PartialDerivatives::value_type& ii, rContinuityCell[i]._dv)
	    {
	      if (ii.first < 5*nCells)
		{
		  bigEndianInteger = ii.first;
		  LowEndian2BigEndian(bigEndianInteger);
		  fwrite(&bigEndianInteger, sizeof(int), 1, dRdUVWPNuTFileBinary);
		}
	      else
		{
		  bigEndianInteger = ii.first-5*nCells;
		  LowEndian2BigEndian(bigEndianInteger);
		  fwrite(&bigEndianInteger, sizeof(int), 1, dRdBetaFileBinary);
		}
	    }
	  foreach(const typename Rapid::PartialDerivatives::value_type& ii, rSACell[i]._dv)
	    {
	      if (ii.first < 5*nCells)
		{
		  bigEndianInteger = ii.first;
		  LowEndian2BigEndian(bigEndianInteger);
		  fwrite(&bigEndianInteger, sizeof(int), 1, dRdUVWPNuTFileBinary);
		}
	      else
		{
		  bigEndianInteger = ii.first-5*nCells;
		  LowEndian2BigEndian(bigEndianInteger);
		  fwrite(&bigEndianInteger, sizeof(int), 1, dRdBetaFileBinary);
		}
	    }
	}	  
      // Values of all non-zeros for both dRdUVWP and dRdBeta
      for(int i=0; i<nCells; i++)
	{
	  for (int j=0; j<3; j++)
	    {
	      foreach(const typename Rapid::PartialDerivatives::value_type& ii, rMomentumCell[i][j]._dv)
		{
		  bigEndianDouble = ii.second;
		  LowEndian2BigEndian(bigEndianDouble);
		  if (ii.first < 5*nCells)
		    fwrite(&bigEndianDouble, sizeof(double), 1, dRdUVWPNuTFileBinary);
		  else
		    fwrite(&bigEndianDouble, sizeof(double), 1, dRdBetaFileBinary);
		}
	    }
	  foreach(const typename Rapid::PartialDerivatives::value_type& ii, rContinuityCell[i]._dv)
	    {
	      bigEndianDouble = ii.second;
	      LowEndian2BigEndian(bigEndianDouble);
	      if (ii.first < 5*nCells)
		fwrite(&bigEndianDouble, sizeof(double), 1, dRdUVWPNuTFileBinary);
	      else
		fwrite(&bigEndianDouble, sizeof(double), 1, dRdBetaFileBinary);
	    }
	  foreach(const typename Rapid::PartialDerivatives::value_type& ii, rSACell[i]._dv)
	    {
	      bigEndianDouble = ii.second;
	      LowEndian2BigEndian(bigEndianDouble);
	      if (ii.first < 5*nCells)
		fwrite(&bigEndianDouble, sizeof(double), 1, dRdUVWPNuTFileBinary);
	      else
		fwrite(&bigEndianDouble, sizeof(double), 1, dRdBetaFileBinary);
	    }	    
	}

      fclose(dRdUVWPNuTFileBinary);
      fclose(dRdBetaFileBinary);
    }

}


void WriteObjectiveFunctionGradientToPetscFlowTurbulent()
{
  for ( int id = 0; id < _meshes.size(); id++ )
    {
      const Mesh& mesh = *_meshes[id];
      const StorageSite& cells = mesh.getCells();
      const int nCells = cells.getCountLevel1();
      const int nCellsWithoutGhosts = cells.getSelfCount();


      double temporaryArray[5*nCells+_nDesignVariables];
      memset(temporaryArray, 0.0, (5*nCells+_nDesignVariables)*sizeof(double));
    
      double scaleFlowModel = _options["scaleFlowModelObjFunction"]._v;            
      foreach(const typename Rapid::PartialDerivatives::value_type& ii, _objFunctionFlowModel._dv)
	{
	  temporaryArray[ii.first] = scaleFlowModel*ii.second;
	}

      double scaleSpalartAllmarasModel = _options["scaleSpalartAllmarasModelObjFunction"]._v;
      foreach(const typename Rapid::PartialDerivatives::value_type& ii, _objFunctionSpalartAllmarasModel._dv)
	{
	  temporaryArray[ii.first] += scaleSpalartAllmarasModel*ii.second;
	}

      //Write in binary format so that Petsc can read directly
      //Temporary variable for big endian version of the variable
      int bigEndianInteger;
      double bigEndianDouble;
      //Writing dcdPhi
      string dcdUVWPNuTFileNameBinary = "dcdUVWPNuT.binary";
      FILE *dcdUVWPNuTFileBinary = fopen(dcdUVWPNuTFileNameBinary.c_str(),"wb"); 
      bigEndianInteger = 1211214;
      LowEndian2BigEndian(bigEndianInteger);
      fwrite(&bigEndianInteger, sizeof(int), 1, dcdUVWPNuTFileBinary);
                
      bigEndianInteger = 5*nCells;
      LowEndian2BigEndian(bigEndianInteger);
      fwrite(&bigEndianInteger, sizeof(int), 1, dcdUVWPNuTFileBinary);
      
      for(int i=0; i<5*nCells; i++)
	{
	  bigEndianDouble = temporaryArray[i];
	  LowEndian2BigEndian(bigEndianDouble);
	  fwrite(&bigEndianDouble, sizeof(double), 1, dcdUVWPNuTFileBinary);
	}
      fclose(dcdUVWPNuTFileBinary);

      //Writing dcdBeta
      string dcdBetaFileNameBinary = "dcdBeta.binary";
      FILE *dcdBetaFileBinary = fopen(dcdBetaFileNameBinary.c_str(),"wb"); 
      bigEndianInteger = 1211214;
      LowEndian2BigEndian(bigEndianInteger);
      fwrite(&bigEndianInteger, sizeof(int), 1, dcdBetaFileBinary);
      
      bigEndianInteger = _nDesignVariables;
      LowEndian2BigEndian(bigEndianInteger);
      fwrite(&bigEndianInteger, sizeof(int), 1, dcdBetaFileBinary);

      //for(int i=4*nCells; i<4*nCells+nCellsWithoutGhosts; i++)
      for(int i=5*nCells; i<5*nCells+_nDesignVariables; i++)
	{
	  bigEndianDouble = temporaryArray[i];
	  LowEndian2BigEndian(bigEndianDouble);
	  fwrite(&bigEndianDouble, sizeof(double), 1, dcdBetaFileBinary);
	}
      fclose(dcdBetaFileBinary);
    }
}

#endif
